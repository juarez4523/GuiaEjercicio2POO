﻿namespace Transporte_Público
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtpFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.dtpFechaContratacion = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLicencia = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dgvChoferes = new System.Windows.Forms.DataGridView();
            this.btnEliminarc = new System.Windows.Forms.Button();
            this.btnModificarc = new System.Windows.Forms.Button();
            this.btnAgregarc = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnEliminarb = new System.Windows.Forms.Button();
            this.btnModificarb = new System.Windows.Forms.Button();
            this.btnAgregarb = new System.Windows.Forms.Button();
            this.dgvBuses = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbChofer = new System.Windows.Forms.ComboBox();
            this.txtCapacidad = new System.Windows.Forms.TextBox();
            this.txtModelo = new System.Windows.Forms.TextBox();
            this.txtPlaca = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnEliminarR = new System.Windows.Forms.Button();
            this.btnModificarR = new System.Windows.Forms.Button();
            this.btnAgregarR = new System.Windows.Forms.Button();
            this.dgvRutas = new System.Windows.Forms.DataGridView();
            this.txtPuntoFin = new System.Windows.Forms.TextBox();
            this.txtPuntoInicio = new System.Windows.Forms.TextBox();
            this.txtNombreRuta = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.dtpFechaVenta = new System.Windows.Forms.DateTimePicker();
            this.cmbRuta = new System.Windows.Forms.ComboBox();
            this.btnEliminarbo = new System.Windows.Forms.Button();
            this.btnModificarbo = new System.Windows.Forms.Button();
            this.btnAgregarbo = new System.Windows.Forms.Button();
            this.dgvBoletos = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbBus = new System.Windows.Forms.ComboBox();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChoferes)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuses)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRutas)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBoletos)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 437);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.dgvChoferes);
            this.tabPage1.Controls.Add(this.btnEliminarc);
            this.tabPage1.Controls.Add(this.btnModificarc);
            this.tabPage1.Controls.Add(this.btnAgregarc);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 411);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Choferes ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtpFechaNacimiento);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.dtpFechaContratacion);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtLicencia);
            this.groupBox1.Controls.Add(this.txtNombre);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(21, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(568, 139);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos del chofer";
            // 
            // dtpFechaNacimiento
            // 
            this.dtpFechaNacimiento.Location = new System.Drawing.Point(149, 108);
            this.dtpFechaNacimiento.Name = "dtpFechaNacimiento";
            this.dtpFechaNacimiento.Size = new System.Drawing.Size(210, 20);
            this.dtpFechaNacimiento.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 113);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 13);
            this.label15.TabIndex = 6;
            this.label15.Text = "Fecha de nacimiento";
            // 
            // dtpFechaContratacion
            // 
            this.dtpFechaContratacion.Location = new System.Drawing.Point(149, 82);
            this.dtpFechaContratacion.Name = "dtpFechaContratacion";
            this.dtpFechaContratacion.Size = new System.Drawing.Size(210, 20);
            this.dtpFechaContratacion.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Fecha de contratacion";
            // 
            // txtLicencia
            // 
            this.txtLicencia.Location = new System.Drawing.Point(392, 28);
            this.txtLicencia.Name = "txtLicencia";
            this.txtLicencia.Size = new System.Drawing.Size(158, 20);
            this.txtLicencia.TabIndex = 3;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(82, 28);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(158, 20);
            this.txtNombre.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(312, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Licencia";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Transporte_Público.Properties.Resources.img2;
            this.pictureBox1.Location = new System.Drawing.Point(646, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(116, 108);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // dgvChoferes
            // 
            this.dgvChoferes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChoferes.Location = new System.Drawing.Point(21, 244);
            this.dgvChoferes.Name = "dgvChoferes";
            this.dgvChoferes.Size = new System.Drawing.Size(719, 164);
            this.dgvChoferes.TabIndex = 10;
            this.dgvChoferes.SelectionChanged += new System.EventHandler(this.dgvChoferes_SelectionChanged);
            // 
            // btnEliminarc
            // 
            this.btnEliminarc.BackColor = System.Drawing.Color.White;
            this.btnEliminarc.Location = new System.Drawing.Point(487, 172);
            this.btnEliminarc.Name = "btnEliminarc";
            this.btnEliminarc.Size = new System.Drawing.Size(118, 40);
            this.btnEliminarc.TabIndex = 9;
            this.btnEliminarc.Text = "Eliminar";
            this.btnEliminarc.UseVisualStyleBackColor = false;
            this.btnEliminarc.Click += new System.EventHandler(this.btnEliminarc_Click);
            this.btnEliminarc.MouseEnter += new System.EventHandler(this.elimC_enter);
            this.btnEliminarc.MouseLeave += new System.EventHandler(this.elimC_leave);
            // 
            // btnModificarc
            // 
            this.btnModificarc.BackColor = System.Drawing.Color.White;
            this.btnModificarc.Location = new System.Drawing.Point(286, 172);
            this.btnModificarc.Name = "btnModificarc";
            this.btnModificarc.Size = new System.Drawing.Size(118, 40);
            this.btnModificarc.TabIndex = 8;
            this.btnModificarc.Text = "Modificar";
            this.btnModificarc.UseVisualStyleBackColor = false;
            this.btnModificarc.Click += new System.EventHandler(this.btnModificarc_Click);
            this.btnModificarc.MouseEnter += new System.EventHandler(this.modic_enter);
            this.btnModificarc.MouseLeave += new System.EventHandler(this.modic_leave);
            // 
            // btnAgregarc
            // 
            this.btnAgregarc.BackColor = System.Drawing.Color.White;
            this.btnAgregarc.Location = new System.Drawing.Point(93, 172);
            this.btnAgregarc.Name = "btnAgregarc";
            this.btnAgregarc.Size = new System.Drawing.Size(118, 40);
            this.btnAgregarc.TabIndex = 6;
            this.btnAgregarc.Text = "Agregar";
            this.btnAgregarc.UseVisualStyleBackColor = false;
            this.btnAgregarc.Click += new System.EventHandler(this.btnAgregarc_Click);
            this.btnAgregarc.MouseEnter += new System.EventHandler(this.agregarc_enter);
            this.btnAgregarc.MouseLeave += new System.EventHandler(this.agregar);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.btnEliminarb);
            this.tabPage2.Controls.Add(this.btnModificarb);
            this.tabPage2.Controls.Add(this.btnAgregarb);
            this.tabPage2.Controls.Add(this.dgvBuses);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.cmbChofer);
            this.tabPage2.Controls.Add(this.txtCapacidad);
            this.tabPage2.Controls.Add(this.txtModelo);
            this.tabPage2.Controls.Add(this.txtPlaca);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 411);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Buses ";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Transporte_Público.Properties.Resources.img2;
            this.pictureBox2.Location = new System.Drawing.Point(649, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(116, 108);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // btnEliminarb
            // 
            this.btnEliminarb.BackColor = System.Drawing.Color.White;
            this.btnEliminarb.Location = new System.Drawing.Point(520, 185);
            this.btnEliminarb.Name = "btnEliminarb";
            this.btnEliminarb.Size = new System.Drawing.Size(118, 40);
            this.btnEliminarb.TabIndex = 13;
            this.btnEliminarb.Text = "Eliminar";
            this.btnEliminarb.UseVisualStyleBackColor = false;
            this.btnEliminarb.Click += new System.EventHandler(this.btnEliminarb_Click);
            this.btnEliminarb.MouseEnter += new System.EventHandler(this.elimB_enter);
            this.btnEliminarb.MouseLeave += new System.EventHandler(this.elimB_leave);
            // 
            // btnModificarb
            // 
            this.btnModificarb.BackColor = System.Drawing.Color.White;
            this.btnModificarb.Location = new System.Drawing.Point(310, 185);
            this.btnModificarb.Name = "btnModificarb";
            this.btnModificarb.Size = new System.Drawing.Size(118, 40);
            this.btnModificarb.TabIndex = 12;
            this.btnModificarb.Text = "Modificar";
            this.btnModificarb.UseVisualStyleBackColor = false;
            this.btnModificarb.Click += new System.EventHandler(this.btnModificarb_Click);
            this.btnModificarb.MouseEnter += new System.EventHandler(this.modiB_enter);
            this.btnModificarb.MouseLeave += new System.EventHandler(this.modiB_leave);
            // 
            // btnAgregarb
            // 
            this.btnAgregarb.BackColor = System.Drawing.Color.White;
            this.btnAgregarb.Location = new System.Drawing.Point(93, 185);
            this.btnAgregarb.Name = "btnAgregarb";
            this.btnAgregarb.Size = new System.Drawing.Size(118, 40);
            this.btnAgregarb.TabIndex = 10;
            this.btnAgregarb.Text = "Agregar";
            this.btnAgregarb.UseVisualStyleBackColor = false;
            this.btnAgregarb.Click += new System.EventHandler(this.btnAgregarb_Click);
            this.btnAgregarb.MouseEnter += new System.EventHandler(this.agrebus_enter);
            this.btnAgregarb.MouseLeave += new System.EventHandler(this.agrebus_leave);
            // 
            // dgvBuses
            // 
            this.dgvBuses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBuses.Location = new System.Drawing.Point(25, 243);
            this.dgvBuses.Name = "dgvBuses";
            this.dgvBuses.Size = new System.Drawing.Size(717, 161);
            this.dgvBuses.TabIndex = 8;
            this.dgvBuses.SelectionChanged += new System.EventHandler(this.dgvBuses_SelectionChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(363, 121);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Chofer";
            // 
            // cmbChofer
            // 
            this.cmbChofer.FormattingEnabled = true;
            this.cmbChofer.Location = new System.Drawing.Point(437, 113);
            this.cmbChofer.Name = "cmbChofer";
            this.cmbChofer.Size = new System.Drawing.Size(175, 21);
            this.cmbChofer.TabIndex = 6;
            // 
            // txtCapacidad
            // 
            this.txtCapacidad.Location = new System.Drawing.Point(119, 114);
            this.txtCapacidad.Name = "txtCapacidad";
            this.txtCapacidad.Size = new System.Drawing.Size(163, 20);
            this.txtCapacidad.TabIndex = 5;
            // 
            // txtModelo
            // 
            this.txtModelo.Location = new System.Drawing.Point(437, 30);
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.Size = new System.Drawing.Size(163, 20);
            this.txtModelo.TabIndex = 4;
            // 
            // txtPlaca
            // 
            this.txtPlaca.Location = new System.Drawing.Point(119, 30);
            this.txtPlaca.Name = "txtPlaca";
            this.txtPlaca.Size = new System.Drawing.Size(163, 20);
            this.txtPlaca.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Capacidad";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(363, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Modelo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(64, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Placa";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.pictureBox3);
            this.tabPage3.Controls.Add(this.btnEliminarR);
            this.tabPage3.Controls.Add(this.btnModificarR);
            this.tabPage3.Controls.Add(this.btnAgregarR);
            this.tabPage3.Controls.Add(this.dgvRutas);
            this.tabPage3.Controls.Add(this.txtPuntoFin);
            this.tabPage3.Controls.Add(this.txtPuntoInicio);
            this.tabPage3.Controls.Add(this.txtNombreRuta);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(768, 411);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Rutas ";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Transporte_Público.Properties.Resources.img2;
            this.pictureBox3.Location = new System.Drawing.Point(652, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(116, 108);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 27;
            this.pictureBox3.TabStop = false;
            // 
            // btnEliminarR
            // 
            this.btnEliminarR.BackColor = System.Drawing.Color.White;
            this.btnEliminarR.Location = new System.Drawing.Point(546, 173);
            this.btnEliminarR.Name = "btnEliminarR";
            this.btnEliminarR.Size = new System.Drawing.Size(118, 40);
            this.btnEliminarR.TabIndex = 26;
            this.btnEliminarR.Text = "Eliminar";
            this.btnEliminarR.UseVisualStyleBackColor = false;
            this.btnEliminarR.Click += new System.EventHandler(this.btnEliminarR_Click);
            this.btnEliminarR.MouseEnter += new System.EventHandler(this.elimR_enter);
            this.btnEliminarR.MouseLeave += new System.EventHandler(this.elimR_leave);
            // 
            // btnModificarR
            // 
            this.btnModificarR.BackColor = System.Drawing.Color.White;
            this.btnModificarR.Location = new System.Drawing.Point(323, 173);
            this.btnModificarR.Name = "btnModificarR";
            this.btnModificarR.Size = new System.Drawing.Size(118, 40);
            this.btnModificarR.TabIndex = 25;
            this.btnModificarR.Text = "Modificar";
            this.btnModificarR.UseVisualStyleBackColor = false;
            this.btnModificarR.Click += new System.EventHandler(this.btnModificarR_Click);
            this.btnModificarR.MouseEnter += new System.EventHandler(this.modiR_enter);
            this.btnModificarR.MouseLeave += new System.EventHandler(this.modiR_leave);
            // 
            // btnAgregarR
            // 
            this.btnAgregarR.BackColor = System.Drawing.Color.White;
            this.btnAgregarR.Location = new System.Drawing.Point(94, 173);
            this.btnAgregarR.Name = "btnAgregarR";
            this.btnAgregarR.Size = new System.Drawing.Size(118, 40);
            this.btnAgregarR.TabIndex = 23;
            this.btnAgregarR.Text = "Agregar";
            this.btnAgregarR.UseVisualStyleBackColor = false;
            this.btnAgregarR.Click += new System.EventHandler(this.btnAgregarR_Click);
            this.btnAgregarR.MouseEnter += new System.EventHandler(this.agreRuta_enter);
            this.btnAgregarR.MouseLeave += new System.EventHandler(this.agreRuta_leave);
            // 
            // dgvRutas
            // 
            this.dgvRutas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRutas.Location = new System.Drawing.Point(26, 231);
            this.dgvRutas.Name = "dgvRutas";
            this.dgvRutas.Size = new System.Drawing.Size(717, 161);
            this.dgvRutas.TabIndex = 22;
            this.dgvRutas.SelectionChanged += new System.EventHandler(this.dgvRutas_SelectionChanged);
            // 
            // txtPuntoFin
            // 
            this.txtPuntoFin.Location = new System.Drawing.Point(120, 102);
            this.txtPuntoFin.Name = "txtPuntoFin";
            this.txtPuntoFin.Size = new System.Drawing.Size(163, 20);
            this.txtPuntoFin.TabIndex = 19;
            // 
            // txtPuntoInicio
            // 
            this.txtPuntoInicio.Location = new System.Drawing.Point(457, 18);
            this.txtPuntoInicio.Name = "txtPuntoInicio";
            this.txtPuntoInicio.Size = new System.Drawing.Size(163, 20);
            this.txtPuntoInicio.TabIndex = 18;
            // 
            // txtNombreRuta
            // 
            this.txtNombreRuta.Location = new System.Drawing.Point(120, 18);
            this.txtNombreRuta.Name = "txtNombreRuta";
            this.txtNombreRuta.Size = new System.Drawing.Size(163, 20);
            this.txtNombreRuta.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(41, 109);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Punto final";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(364, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 13);
            this.label10.TabIndex = 15;
            this.label10.Text = "Punto de inicio";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(23, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Nombre de ruta";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.pictureBox4);
            this.tabPage4.Controls.Add(this.dtpFechaVenta);
            this.tabPage4.Controls.Add(this.cmbRuta);
            this.tabPage4.Controls.Add(this.btnEliminarbo);
            this.tabPage4.Controls.Add(this.btnModificarbo);
            this.tabPage4.Controls.Add(this.btnAgregarbo);
            this.tabPage4.Controls.Add(this.dgvBoletos);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.cmbBus);
            this.tabPage4.Controls.Add(this.txtPrecio);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(768, 411);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Boletos ";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Transporte_Público.Properties.Resources.img2;
            this.pictureBox4.Location = new System.Drawing.Point(652, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(116, 108);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 31;
            this.pictureBox4.TabStop = false;
            // 
            // dtpFechaVenta
            // 
            this.dtpFechaVenta.Location = new System.Drawing.Point(438, 19);
            this.dtpFechaVenta.Name = "dtpFechaVenta";
            this.dtpFechaVenta.Size = new System.Drawing.Size(204, 20);
            this.dtpFechaVenta.TabIndex = 28;
            // 
            // cmbRuta
            // 
            this.cmbRuta.FormattingEnabled = true;
            this.cmbRuta.Location = new System.Drawing.Point(120, 101);
            this.cmbRuta.Name = "cmbRuta";
            this.cmbRuta.Size = new System.Drawing.Size(175, 21);
            this.cmbRuta.TabIndex = 27;
            // 
            // btnEliminarbo
            // 
            this.btnEliminarbo.BackColor = System.Drawing.Color.White;
            this.btnEliminarbo.Location = new System.Drawing.Point(495, 185);
            this.btnEliminarbo.Name = "btnEliminarbo";
            this.btnEliminarbo.Size = new System.Drawing.Size(118, 40);
            this.btnEliminarbo.TabIndex = 26;
            this.btnEliminarbo.Text = "Eliminar";
            this.btnEliminarbo.UseVisualStyleBackColor = false;
            this.btnEliminarbo.Click += new System.EventHandler(this.btnEliminarbo_Click);
            this.btnEliminarbo.MouseEnter += new System.EventHandler(this.elimbo_enter);
            this.btnEliminarbo.MouseLeave += new System.EventHandler(this.elimbo_leave);
            // 
            // btnModificarbo
            // 
            this.btnModificarbo.BackColor = System.Drawing.Color.White;
            this.btnModificarbo.Location = new System.Drawing.Point(314, 185);
            this.btnModificarbo.Name = "btnModificarbo";
            this.btnModificarbo.Size = new System.Drawing.Size(118, 40);
            this.btnModificarbo.TabIndex = 25;
            this.btnModificarbo.Text = "Modificar";
            this.btnModificarbo.UseVisualStyleBackColor = false;
            this.btnModificarbo.Click += new System.EventHandler(this.btnModificarbo_Click);
            this.btnModificarbo.MouseEnter += new System.EventHandler(this.modiBo_enter);
            this.btnModificarbo.MouseLeave += new System.EventHandler(this.modiBo_leave);
            // 
            // btnAgregarbo
            // 
            this.btnAgregarbo.BackColor = System.Drawing.Color.White;
            this.btnAgregarbo.Location = new System.Drawing.Point(120, 185);
            this.btnAgregarbo.Name = "btnAgregarbo";
            this.btnAgregarbo.Size = new System.Drawing.Size(118, 40);
            this.btnAgregarbo.TabIndex = 23;
            this.btnAgregarbo.Text = "Agregar";
            this.btnAgregarbo.UseVisualStyleBackColor = false;
            this.btnAgregarbo.Click += new System.EventHandler(this.btnAgregarbo_Click);
            this.btnAgregarbo.MouseEnter += new System.EventHandler(this.agrebo_enter);
            this.btnAgregarbo.MouseLeave += new System.EventHandler(this.agrebo_leave);
            // 
            // dgvBoletos
            // 
            this.dgvBoletos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBoletos.Location = new System.Drawing.Point(26, 231);
            this.dgvBoletos.Name = "dgvBoletos";
            this.dgvBoletos.Size = new System.Drawing.Size(717, 161);
            this.dgvBoletos.TabIndex = 22;
            this.dgvBoletos.SelectionChanged += new System.EventHandler(this.dgvBoletos_SelectionChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(364, 109);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Bus";
            // 
            // cmbBus
            // 
            this.cmbBus.FormattingEnabled = true;
            this.cmbBus.Location = new System.Drawing.Point(438, 101);
            this.cmbBus.Name = "cmbBus";
            this.cmbBus.Size = new System.Drawing.Size(175, 21);
            this.cmbBus.TabIndex = 20;
            // 
            // txtPrecio
            // 
            this.txtPrecio.Location = new System.Drawing.Point(120, 18);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(163, 20);
            this.txtPrecio.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(65, 104);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 16;
            this.label12.Text = "Ruta";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(350, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "Fecha de venta";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(65, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Precio";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Transporte publico";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChoferes)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuses)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRutas)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBoletos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dgvChoferes;
        private System.Windows.Forms.Button btnEliminarc;
        private System.Windows.Forms.Button btnModificarc;
        private System.Windows.Forms.Button btnAgregarc;
        private System.Windows.Forms.DateTimePicker dtpFechaContratacion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLicencia;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbChofer;
        private System.Windows.Forms.TextBox txtCapacidad;
        private System.Windows.Forms.TextBox txtModelo;
        private System.Windows.Forms.TextBox txtPlaca;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnEliminarb;
        private System.Windows.Forms.Button btnModificarb;
        private System.Windows.Forms.Button btnAgregarb;
        private System.Windows.Forms.DataGridView dgvBuses;
        private System.Windows.Forms.Button btnEliminarR;
        private System.Windows.Forms.Button btnModificarR;
        private System.Windows.Forms.Button btnAgregarR;
        private System.Windows.Forms.DataGridView dgvRutas;
        private System.Windows.Forms.TextBox txtPuntoFin;
        private System.Windows.Forms.TextBox txtPuntoInicio;
        private System.Windows.Forms.TextBox txtNombreRuta;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtpFechaVenta;
        private System.Windows.Forms.ComboBox cmbRuta;
        private System.Windows.Forms.Button btnEliminarbo;
        private System.Windows.Forms.Button btnModificarbo;
        private System.Windows.Forms.Button btnAgregarbo;
        private System.Windows.Forms.DataGridView dgvBoletos;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbBus;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.DateTimePicker dtpFechaNacimiento;
        private System.Windows.Forms.Label label15;
    }
}

