﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComandosCreate.Model
{
    public class Bus
    {
        public int IdBus { get; set; }  
        public string Placa { get; set; }
        public string Modelo { get; set; }
        public int Capacidad { get; set; }

    
        public int IdChofer { get; set; }


        public virtual Chofer Chofer { get; set; }

        public string MostrarInfoBus()
        {
            return $"Placa: {Placa}, Modelo: {Modelo}, Capacidad: {Capacidad}, Chofer: {Chofer?.Nombre}";
        }
    }
}
