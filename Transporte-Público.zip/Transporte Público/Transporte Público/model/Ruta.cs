﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComandosCreate.Model
{
    public class Ruta
    {
        public int IdRuta { get; set; }
        public string NombreRuta { get; set; }
        public string PuntoInicio { get; set; }
        public string PuntoFin { get; set; }
       

        public override string ToString()
        {
            return $"Ruta: {NombreRuta}, Inicio: {PuntoInicio}, Fin: {PuntoFin}";
        }
    }
}
