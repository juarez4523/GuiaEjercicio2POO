﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComandosCreate.Model
{
    public class Chofer:Persona
    {
        public int IdChofer { get; set; }  
        public string Licencia { get; set; }
        public DateTime FechaContratacion { get; set; }

        public string MostrarDatosCompleto()
        {
            return $"{MostrarDatos()}, Licencia: {Licencia}, Fecha de Contratación: {FechaContratacion.ToShortDateString()}";
        }
    }
}
