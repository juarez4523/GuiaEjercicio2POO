﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComandosCreate.Model
{
    public class Persona
    {
        public string Nombre { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public virtual string MostrarDatos()
        {
            return $"Nombre: {Nombre}, Fecha de Nacimiento: {FechaNacimiento.ToShortDateString()}";

        }
    }
}
