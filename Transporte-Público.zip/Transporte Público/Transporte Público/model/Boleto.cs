﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComandosCreate.Model
{
    public class Boleto
    {
        public int IdBoleto { get; set; }
        public int IdBus { get; set; }
        public int IdRuta { get; set; } 
        public virtual Bus Bus { get; set; }
        public virtual Ruta Ruta { get; set; }

        public DateTime FechaVenta { get; set; }
        public decimal Precio { get; set; }

        


        public string MostrarInfoBoleto()
        {
            return $"Boleto - Bus: {Bus?.Placa}, Ruta: {Ruta?.NombreRuta}, Fecha: {FechaVenta.ToShortDateString()}, Precio: {Precio:C}";
        }
    }
}
