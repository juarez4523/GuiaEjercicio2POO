﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComandosCreate.Model;

namespace Transporte_Público
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void btnAgregarc_Click(object sender, EventArgs e)
        {
           if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El nombre es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombre.Focus();
                return;
            }
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtNombre.Text, @"^[a-zA-ZáéíóúüñÁÉÍÓÚÜÑ\s]+$"))
            {
                MessageBox.Show("El nombre  debe tener solo letras ", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombre.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtLicencia.Text))
            {
                MessageBox.Show("La licencia es obligatoria", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLicencia.Focus();
                return;
            }

            // Validar formato de licencia (solo letras y números)
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtLicencia.Text, @"^[A-Za-z0-9]+$"))
            {
                MessageBox.Show("La licencia solo puede contener letras y números", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLicencia.Focus();
                return;
            }

            // Validar fecha de nacimiento
            if (dtpFechaNacimiento.Value > DateTime.Now.AddYears(-18))
            {
                MessageBox.Show("El chofer debe ser mayor de 18 años", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar fecha de contratación
            if (dtpFechaContratacion.Value > DateTime.Now)
            {
                MessageBox.Show("La fecha de contratación no puede ser futura", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    // Validar que la licencia no exista
                    if (db.Choferes.Any(c => c.Licencia == txtLicencia.Text))
                    {
                        MessageBox.Show("Ya existe un chofer con esa licencia", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtLicencia.Focus();
                        return;
                    }

                    var chofer = new Chofer
                    {
                        Nombre = txtNombre.Text.Trim(),
                        FechaNacimiento = dtpFechaNacimiento.Value,
                        Licencia = txtLicencia.Text.Trim().ToUpper(),
                        FechaContratacion = dtpFechaContratacion.Value
                    };

                    db.Choferes.Add(chofer);
                    db.SaveChanges();
                }

                MessageBox.Show("Chofer guardado con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarChoferes();
                CargarCombos();
                LimpiarCamposChofer();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAgregarb_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPlaca.Text))
            {
                MessageBox.Show("La placa es obligatoria", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPlaca.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtModelo.Text))
            {
                MessageBox.Show("El modelo es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtModelo.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCapacidad.Text))
            {
                MessageBox.Show("La capacidad es obligatoria", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCapacidad.Focus();
                return;
            }

            // Validar formato de placa (letras y números)
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtPlaca.Text, @"^[A-Za-z0-9\-]+$"))
            {
                MessageBox.Show("La placa solo puede contener letras, números y guiones", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPlaca.Focus();
                return;
            }

            // Validar capacidad
            if (!int.TryParse(txtCapacidad.Text, out int capacidad) || capacidad <= 0)
            {
                MessageBox.Show("La capacidad debe ser un número mayor a 0", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCapacidad.Focus();
                return;
            }

            if (capacidad > 100)
            {
                MessageBox.Show("La capacidad no puede ser mayor a 100 pasajeros", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCapacidad.Focus();
                return;
            }

            // Validar chofer seleccionado
            if (cmbChofer.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar un chofer", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbChofer.Focus();
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    // Validar que la placa no exista
                    if (db.Buses.Any(b => b.Placa.ToUpper() == txtPlaca.Text.Trim().ToUpper()))
                    {
                        MessageBox.Show("Ya existe un bus con esa placa", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtPlaca.Focus();
                        return;
                    }

                    // Validar que el chofer no tenga ya un bus asignado
                    int idChofer = (int)cmbChofer.SelectedValue;
                    if (db.Buses.Any(b => b.IdChofer == idChofer))
                    {
                        MessageBox.Show("El chofer seleccionado ya tiene un bus asignado", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        cmbChofer.Focus();
                        return;
                    }

                    var bus = new Bus
                    {
                        Placa = txtPlaca.Text.Trim().ToUpper(),
                        Modelo = txtModelo.Text.Trim(),
                        Capacidad = capacidad,
                        IdChofer = idChofer
                    };

                    db.Buses.Add(bus);
                    db.SaveChanges();
                }

                MessageBox.Show("Bus guardado con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarBuses();
                CargarCombos();
                LimpiarCamposBus();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAgregarR_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombreRuta.Text))
            {
                MessageBox.Show("El nombre de la ruta es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombreRuta.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPuntoInicio.Text))
            {
                MessageBox.Show("El punto de inicio es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPuntoInicio.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPuntoFin.Text))
            {
                MessageBox.Show("El punto final es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPuntoFin.Focus();
                return;
            }

            // Validar que punto inicio y fin no sean iguales
            if (txtPuntoInicio.Text.Trim().ToUpper() == txtPuntoFin.Text.Trim().ToUpper())
            {
                MessageBox.Show("El punto de inicio y final no pueden ser iguales", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPuntoFin.Focus();
                return;
            }

            // Validar longitud mínima
            if (txtNombreRuta.Text.Trim().Length < 3)
            {
                MessageBox.Show("El nombre de la ruta debe tener al menos 3 caracteres ", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombreRuta.Focus();
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(txtNombreRuta.Text, @"^[a-zA-ZáéíóúüñÁÉÍÓÚÜÑ\s]+$"))
            {
                MessageBox.Show("El nombre de la ruta debe tener solo letras ", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombreRuta.Focus();
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    // Validar que el nombre de ruta no exista
                    if (db.Rutas.Any(r => r.NombreRuta.ToUpper() == txtNombreRuta.Text.Trim().ToUpper()))
                    {
                        MessageBox.Show("Ya existe una ruta con ese nombre", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtNombreRuta.Focus();
                        return;
                    }

                    // Validar que no exista la misma combinación de puntos
                    string puntoInicio = txtPuntoInicio.Text.Trim();
                    string puntoFin = txtPuntoFin.Text.Trim();

                    if (db.Rutas.Any(r => r.PuntoInicio.ToUpper() == puntoInicio.ToUpper() &&
                                         r.PuntoFin.ToUpper() == puntoFin.ToUpper()))
                    {
                        MessageBox.Show("Ya existe una ruta con los mismos puntos de inicio y fin", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    var ruta = new Ruta
                    {
                        NombreRuta = txtNombreRuta.Text.Trim(),
                        PuntoInicio = puntoInicio,
                        PuntoFin = puntoFin
                    };

                    db.Rutas.Add(ruta);
                    db.SaveChanges();
                }

                MessageBox.Show("Ruta guardada con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarRutas();
                CargarCombos();
                LimpiarCamposRuta();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAgregarbo_Click(object sender, EventArgs e)
        {
            // Validar selección de bus
            if (cmbBus.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar un bus", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbBus.Focus();
                return;
            }

            // Validar selección de ruta
            if (cmbRuta.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar una ruta", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbRuta.Focus();
                return;
            }
            // Validar precio
            if (string.IsNullOrWhiteSpace(txtPrecio.Text) || !decimal.TryParse(txtPrecio.Text, out decimal precio) || precio <= 0)
            {
                MessageBox.Show("Debe ingresar un precio válido", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrecio.Focus();
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    if (cmbBus.SelectedValue == null || cmbRuta.SelectedValue == null)
                    {
                        MessageBox.Show("Debes seleccionar un bus y una ruta.");
                        return;
                    }

                    var boleto = new Boleto
                    {
                        IdBus = (int)cmbBus.SelectedValue,
                        IdRuta = (int)cmbRuta.SelectedValue,
                        FechaVenta = dtpFechaVenta.Value,
                        Precio = decimal.Parse(txtPrecio.Text)
                    };

                    db.Boletos.Add(boleto);
                    db.SaveChanges();
                }

                MessageBox.Show("Boleto guardado con éxito 🎫");
                CargarBoletos();
                LimpiarCamposBoleto();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error al guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }




        }


        private void Form1_Load(object sender, EventArgs e)
        {
            CargarTodosLosDatos();

            using (var db = new TransporteDbContext())
            {

                cmbBus.DataSource = db.Buses
                                     .Select(b => new { b.IdBus, Detalle = b.Placa + " - " + b.Modelo })
                                     .ToList();
                cmbBus.DisplayMember = "Detalle";
                cmbBus.ValueMember = "IdBus";


                cmbRuta.DataSource = db.Rutas.ToList();
                cmbRuta.DisplayMember = "NombreRuta";
                cmbRuta.ValueMember = "IdRuta";
            }


        }

        private void CargarTodosLosDatos()
        {
            CargarChoferes();
            CargarBuses();
            CargarRutas();
            CargarBoletos();
            CargarCombos();
        }
        private void CargarChoferes()
        {
            try
            {
                using (var db = new TransporteDbContext())
                {
                    var datos = db.Choferes.ToList();
                    dgvChoferes.DataSource = datos.Select(c => new
                    {
                        ID = c.IdChofer,
                        Nombre = c.Nombre,
                        Licencia = c.Licencia,
                        FechaContratacion = c.FechaContratacion.ToString("dd/MM/yyyy"),
                        FechaNacimiento = c.FechaNacimiento.ToString("dd/MM/yyyy")
                    }).ToList();

                    dgvChoferes.Columns["ID"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void CargarBuses()
        {
            try
            {
                using (var db = new TransporteDbContext())
                {
                    var datos = db.Buses.Include("Chofer").ToList();
                    dgvBuses.DataSource = datos.Select(b => new
                    {
                        ID = b.IdBus,
                        Placa = b.Placa,
                        Modelo = b.Modelo,
                        Capacidad = b.Capacidad,
                        Chofer = b.Chofer.Nombre,
                        IdChofer = b.IdChofer
                    }).ToList();

                    dgvBuses.Columns["ID"].Visible = false;
                    dgvBuses.Columns["IdChofer"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void CargarRutas()
        {
            try
            {
                using (var db = new TransporteDbContext())
                {
                    var datos = db.Rutas.ToList();
                    dgvRutas.DataSource = datos.Select(r => new
                    {
                        ID = r.IdRuta,
                        NombreRuta = r.NombreRuta,
                        PuntoInicio = r.PuntoInicio,
                        PuntoFin = r.PuntoFin
                    }).ToList();

                    dgvRutas.Columns["ID"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        
        private void CargarBoletos()
        {
            try
            {
                using (var db = new TransporteDbContext())
                {
                    var datos = db.Boletos.Include("Bus").Include("Bus.Chofer").Include("Ruta").ToList();
                    dgvBoletos.DataSource = datos.Select(bol => new
                    {
                        ID = bol.IdBoleto,
                        Fecha = bol.FechaVenta.ToString("dd/MM/yyyy"),
                        Chofer = bol.Bus.Chofer.Nombre,
                        Bus = bol.Bus.Placa,
                        Ruta = bol.Ruta.NombreRuta,
                        Precio = bol.Precio.ToString("C"),
                        IdBus = bol.IdBus,
                        IdRuta = bol.IdRuta
                    }).ToList();

                    dgvBoletos.Columns["ID"].Visible = false;
                    dgvBoletos.Columns["IdBus"].Visible = false;
                    dgvBoletos.Columns["IdRuta"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void LimpiarCamposChofer()
        {
            txtNombre.Clear();
            txtLicencia.Clear();
            dtpFechaContratacion.Value = DateTime.Now;
            dtpFechaNacimiento.Value = DateTime.Now.AddYears(-25); // Edad por defecto
            txtNombre.Focus();
        }

        private void LimpiarCamposBus()
        {
            txtPlaca.Clear();
            txtModelo.Clear();
            txtCapacidad.Clear();
            cmbChofer.SelectedIndex = -1;
            txtPlaca.Focus();
        }

        private void LimpiarCamposRuta()
        {
            txtNombreRuta.Clear();
            txtPuntoInicio.Clear();
            txtPuntoFin.Clear();
            txtNombreRuta.Focus();
        }

        private void LimpiarCamposBoleto()
        {
            cmbBus.SelectedIndex = -1;
            cmbRuta.SelectedIndex = -1;
            txtPrecio.Clear();
            dtpFechaVenta.Value = DateTime.Now;
            txtPrecio.Focus();
        }

        private void CargarCombos()
        {
            try
            {
                using (var db = new TransporteDbContext())
                {
                    // Combo de choferes
                    var choferes = db.Choferes.ToList();
                    cmbChofer.DataSource = choferes;
                    cmbChofer.DisplayMember = "Nombre";
                    cmbChofer.ValueMember = "IdChofer";
                    cmbChofer.SelectedIndex = -1;

                    // Combo de buses
                    var buses = db.Buses.ToList();
                    cmbBus.DataSource = buses.Select(b => new
                    {
                        IdBus = b.IdBus,
                        Texto = b.Placa + " - " + b.Modelo
                    }).ToList();
                    cmbBus.DisplayMember = "Texto";
                    cmbBus.ValueMember = "IdBus";
                    cmbBus.SelectedIndex = -1;

                    // Combo de rutas
                    var rutas = db.Rutas.ToList();
                    cmbRuta.DataSource = rutas;
                    cmbRuta.DisplayMember = "NombreRuta";
                    cmbRuta.ValueMember = "IdRuta";
                    cmbRuta.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            CargarTodosLosDatos();
        }

        private void dgvChoferes_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvChoferes.SelectedRows.Count > 0)
            {
                var fila = dgvChoferes.SelectedRows[0];
                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtLicencia.Text = fila.Cells["Licencia"].Value.ToString();
            }
        }

        private void dgvBuses_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvBuses.SelectedRows.Count > 0)
            {
                var fila = dgvBuses.SelectedRows[0];
                txtPlaca.Text = fila.Cells["Placa"].Value.ToString();
                txtModelo.Text = fila.Cells["Modelo"].Value.ToString();
                txtCapacidad.Text = fila.Cells["Capacidad"].Value.ToString();
                cmbChofer.SelectedValue = fila.Cells["IdChofer"].Value;
            }
        }
        private void dgvRutas_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvRutas.SelectedRows.Count > 0)
            {
                var fila = dgvRutas.SelectedRows[0];
                txtNombreRuta.Text = fila.Cells["NombreRuta"].Value.ToString();
                txtPuntoInicio.Text = fila.Cells["PuntoInicio"].Value.ToString();
                txtPuntoFin.Text = fila.Cells["PuntoFin"].Value.ToString();
            }
        }

        
        private void dgvBoletos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvBoletos.SelectedRows.Count > 0)
            {
                var fila = dgvBoletos.SelectedRows[0];
                cmbBus.SelectedValue = fila.Cells["IdBus"].Value;
                cmbRuta.SelectedValue = fila.Cells["IdRuta"].Value;
                txtPrecio.Text = fila.Cells["Precio"].Value.ToString().Replace("$", "").Replace(",", "");
            }
        }
        
        
        private void agregarc_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.LightBlue;
        }

        private void agregar(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }
        private void agrebus_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.LightBlue;
        }

        private void agrebus_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void agreRuta_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void agreRuta_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.LightBlue;
        }

        private void agrebo_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.LightBlue;
        }

        private void agrebo_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void modic_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.Green;
        }

        private void modic_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void modiB_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.Green;
        }

        private void modiB_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void modiR_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.Green;
        }

        private void modiR_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void modiBo_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.Green;
        }

        private void modiBo_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void elimC_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void elimC_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.Red;
        }

        private void elimB_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.Red;
        }

        private void elimB_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void elimR_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.Red;
        }

        private void elimR_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void elimbo_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.Red;
        }

        private void elimbo_leave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.White;
        }

        private void btnEliminarc_Click(object sender, EventArgs e)
        {
            // Validar que hay una fila seleccionada
            if (dgvChoferes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un chofer para eliminar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la celda ID no sea null
            var cellValue = dgvChoferes.SelectedRows[0].Cells["ID"].Value;
            if (cellValue == null)
            {
                MessageBox.Show("Error al obtener el ID del chofer seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Confirmar eliminación
            if (MessageBox.Show("¿Está seguro de eliminar este chofer?", "Confirmar Eliminación",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    int idChofer = Convert.ToInt32(cellValue);

                    // Verificar si tiene buses asignados
                    if (db.Buses.Any(b => b.IdChofer == idChofer))
                    {
                        MessageBox.Show("No se puede eliminar el chofer porque tiene buses asignados",
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    var chofer = db.Choferes.FirstOrDefault(c => c.IdChofer == idChofer);
                    if (chofer == null)
                    {
                        MessageBox.Show("No se encontró el chofer seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    db.Choferes.Remove(chofer);
                    db.SaveChanges();
                }

                MessageBox.Show("Chofer eliminado con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarChoferes();
                CargarCombos();
                LimpiarCamposChofer();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminarb_Click(object sender, EventArgs e)
        {
            // Validar que hay una fila seleccionada
            if (dgvBuses.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un bus para eliminar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la celda ID no sea null
            var cellValue = dgvBuses.SelectedRows[0].Cells["ID"].Value;
            if (cellValue == null)
            {
                MessageBox.Show("Error al obtener el ID del bus seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (MessageBox.Show("¿Está seguro de eliminar este bus?", "Confirmar Eliminación",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    int idBus = Convert.ToInt32(cellValue);

                    // Verificar si tiene boletos vendidos
                    if (db.Boletos.Any(bol => bol.IdBus == idBus))
                    {
                        MessageBox.Show("No se puede eliminar el bus porque tiene boletos vendidos",
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    var bus = db.Buses.FirstOrDefault(b => b.IdBus == idBus);
                    if (bus == null)
                    {
                        MessageBox.Show("No se encontró el bus seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    db.Buses.Remove(bus);
                    db.SaveChanges();
                }

                MessageBox.Show("Bus eliminado con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarBuses();
                CargarCombos();
                LimpiarCamposBus();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminarR_Click(object sender, EventArgs e)
        {
            // Validar que hay una fila seleccionada
            if (dgvRutas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una ruta para eliminar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la celda ID no sea null
            var cellValue = dgvRutas.SelectedRows[0].Cells["ID"].Value;
            if (cellValue == null)
            {
                MessageBox.Show("Error al obtener el ID de la ruta seleccionada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (MessageBox.Show("¿Está seguro de eliminar esta ruta?", "Confirmar Eliminación",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    int idRuta = Convert.ToInt32(cellValue);

                    // Verificar si tiene boletos vendidos
                    if (db.Boletos.Any(bol => bol.IdRuta == idRuta))
                    {
                        MessageBox.Show("No se puede eliminar la ruta porque tiene boletos vendidos",
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    var ruta = db.Rutas.FirstOrDefault(r => r.IdRuta == idRuta);
                    if (ruta == null)
                    {
                        MessageBox.Show("No se encontró la ruta seleccionada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    db.Rutas.Remove(ruta);
                    db.SaveChanges();
                }

                MessageBox.Show("Ruta eliminada con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarRutas();
                CargarCombos();
                LimpiarCamposRuta();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminarbo_Click(object sender, EventArgs e)
        {
            // Validar que hay una fila seleccionada
            if (dgvBoletos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un boleto para eliminar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la celda ID no sea null
            var cellValue = dgvBoletos.SelectedRows[0].Cells["ID"].Value;
            if (cellValue == null)
            {
                MessageBox.Show("Error al obtener el ID del boleto seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Confirmar eliminación
            if (MessageBox.Show("¿Está seguro de eliminar este boleto?", "Confirmar Eliminación",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    int idBoleto = Convert.ToInt32(cellValue);
                    var boleto = db.Boletos.FirstOrDefault(b => b.IdBoleto == idBoleto);

                    if (boleto == null)
                    {
                        MessageBox.Show("No se encontró el boleto para eliminar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    db.Boletos.Remove(boleto);
                    db.SaveChanges();
                }

                MessageBox.Show("Boleto eliminado con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarBoletos();
                LimpiarCamposBoleto();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        

        private void btnModificarc_Click(object sender, EventArgs e)
        {
            // Validar que hay una fila seleccionada
            if (dgvChoferes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un chofer para modificar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la celda ID no sea null
            var cellValue = dgvChoferes.SelectedRows[0].Cells["ID"].Value;
            if (cellValue == null)
            {
                MessageBox.Show("Error al obtener el ID del chofer seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validaciones de campos obligatorios
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El nombre es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombre.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtLicencia.Text))
            {
                MessageBox.Show("La licencia es obligatoria", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLicencia.Focus();
                return;
            }

            // Validar formato de licencia
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtLicencia.Text, @"^[A-Za-z0-9]+$"))
            {
                MessageBox.Show("La licencia solo puede contener letras y números", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLicencia.Focus();
                return;
            }

            // Validar edad mínima
            if (dtpFechaNacimiento.Value > DateTime.Now.AddYears(-18))
            {
                MessageBox.Show("El chofer debe ser mayor de 18 años", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar fecha de contratación
            if (dtpFechaContratacion.Value > DateTime.Now)
            {
                MessageBox.Show("La fecha de contratación no puede ser futura", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    int idChofer = Convert.ToInt32(cellValue);

                    // Validar licencia única (excluyendo el chofer actual)
                    if (db.Choferes.Any(c => c.Licencia.ToUpper() == txtLicencia.Text.Trim().ToUpper() && c.IdChofer != idChofer))
                    {
                        MessageBox.Show("Ya existe otro chofer con esa licencia", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtLicencia.Focus();
                        return;
                    }

                    var chofer = db.Choferes.FirstOrDefault(c => c.IdChofer == idChofer);
                    if (chofer == null)
                    {
                        MessageBox.Show("No se encontró el chofer seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Actualizar datos
                    chofer.Nombre = txtNombre.Text.Trim();
                    chofer.Licencia = txtLicencia.Text.Trim().ToUpper();
                    chofer.FechaNacimiento = dtpFechaNacimiento.Value;
                    chofer.FechaContratacion = dtpFechaContratacion.Value;

                    db.SaveChanges();
                }

                MessageBox.Show("Chofer modificado con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarChoferes();
                CargarCombos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al modificar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModificarb_Click(object sender, EventArgs e)
        {
            // Validar que hay una fila seleccionada
            if (dgvBuses.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un bus para modificar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la celda ID no sea null
            var cellValue = dgvBuses.SelectedRows[0].Cells["ID"].Value;
            if (cellValue == null)
            {
                MessageBox.Show("Error al obtener el ID del bus seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validaciones de campos obligatorios
            if (string.IsNullOrWhiteSpace(txtPlaca.Text))
            {
                MessageBox.Show("La placa es obligatoria", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPlaca.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtModelo.Text))
            {
                MessageBox.Show("El modelo es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtModelo.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCapacidad.Text))
            {
                MessageBox.Show("La capacidad es obligatoria", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCapacidad.Focus();
                return;
            }

            // Validar formato de placa
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtPlaca.Text, @"^[A-Za-z0-9\-]+$"))
            {
                MessageBox.Show("La placa solo puede contener letras, números y guiones", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPlaca.Focus();
                return;
            }

            // Validar capacidad
            if (!int.TryParse(txtCapacidad.Text, out int capacidad) || capacidad <= 0)
            {
                MessageBox.Show("La capacidad debe ser un número mayor a 0", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCapacidad.Focus();
                return;
            }

            if (capacidad > 100)
            {
                MessageBox.Show("La capacidad no puede ser mayor a 100 pasajeros", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCapacidad.Focus();
                return;
            }

            // Validar chofer seleccionado
            if (cmbChofer.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar un chofer", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbChofer.Focus();
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    int idBus = Convert.ToInt32(cellValue);

                    // Validar placa única (excluyendo el bus actual)
                    if (db.Buses.Any(b => b.Placa.ToUpper() == txtPlaca.Text.Trim().ToUpper() && b.IdBus != idBus))
                    {
                        MessageBox.Show("Ya existe otro bus con esa placa", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtPlaca.Focus();
                        return;
                    }

                    var bus = db.Buses.FirstOrDefault(b => b.IdBus == idBus);
                    if (bus == null)
                    {
                        MessageBox.Show("No se encontró el bus seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Validar chofer único (si cambió)
                    int nuevoIdChofer = (int)cmbChofer.SelectedValue;
                    if (bus.IdChofer != nuevoIdChofer && db.Buses.Any(b => b.IdChofer == nuevoIdChofer))
                    {
                        MessageBox.Show("El chofer seleccionado ya tiene un bus asignado", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        cmbChofer.Focus();
                        return;
                    }

                    // Actualizar datos
                    bus.Placa = txtPlaca.Text.Trim().ToUpper();
                    bus.Modelo = txtModelo.Text.Trim();
                    bus.Capacidad = capacidad;
                    bus.IdChofer = nuevoIdChofer;

                    db.SaveChanges();
                }

                MessageBox.Show("Bus modificado con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarBuses();
                CargarCombos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al modificar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModificarR_Click(object sender, EventArgs e)
        {
            // Validar que hay una fila seleccionada
            if (dgvRutas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una ruta para modificar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la celda ID no sea null
            var cellValue = dgvRutas.SelectedRows[0].Cells["ID"].Value;
            if (cellValue == null)
            {
                MessageBox.Show("Error al obtener el ID de la ruta seleccionada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validaciones de campos obligatorios
            if (string.IsNullOrWhiteSpace(txtNombreRuta.Text))
            {
                MessageBox.Show("El nombre de la ruta es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombreRuta.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPuntoInicio.Text))
            {
                MessageBox.Show("El punto de inicio es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPuntoInicio.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPuntoFin.Text))
            {
                MessageBox.Show("El punto final es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPuntoFin.Focus();
                return;
            }

            // Validar que los puntos no sean iguales
            if (txtPuntoInicio.Text.Trim().ToUpper() == txtPuntoFin.Text.Trim().ToUpper())
            {
                MessageBox.Show("El punto de inicio y final no pueden ser iguales", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPuntoFin.Focus();
                return;
            }

            // Validar longitud mínima
            if (txtNombreRuta.Text.Trim().Length < 3)
            {
                MessageBox.Show("El nombre de la ruta debe tener al menos 3 caracteres", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombreRuta.Focus();
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    int idRuta = Convert.ToInt32(cellValue);

                    // Validar nombre único (excluyendo la ruta actual)
                    if (db.Rutas.Any(r => r.NombreRuta.ToUpper() == txtNombreRuta.Text.Trim().ToUpper() && r.IdRuta != idRuta))
                    {
                        MessageBox.Show("Ya existe otra ruta con ese nombre", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtNombreRuta.Focus();
                        return;
                    }

                    // Validar que no exista la misma combinación de puntos (excluyendo la ruta actual)
                    string puntoInicio = txtPuntoInicio.Text.Trim();
                    string puntoFin = txtPuntoFin.Text.Trim();

                    if (db.Rutas.Any(r => r.PuntoInicio.ToUpper() == puntoInicio.ToUpper() &&
                                         r.PuntoFin.ToUpper() == puntoFin.ToUpper() &&
                                         r.IdRuta != idRuta))
                    {
                        MessageBox.Show("Ya existe otra ruta con los mismos puntos de inicio y fin", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    var ruta = db.Rutas.FirstOrDefault(r => r.IdRuta == idRuta);
                    if (ruta == null)
                    {
                        MessageBox.Show("No se encontró la ruta seleccionada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Actualizar datos
                    ruta.NombreRuta = txtNombreRuta.Text.Trim();
                    ruta.PuntoInicio = puntoInicio;
                    ruta.PuntoFin = puntoFin;

                    db.SaveChanges();
                }

                MessageBox.Show("Ruta modificada con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarRutas();
                CargarCombos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al modificar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModificarbo_Click(object sender, EventArgs e)
        {
            // Validar que hay una fila seleccionada
            if (dgvBoletos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un boleto para modificar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la celda ID no sea null
            var cellValue = dgvBoletos.SelectedRows[0].Cells["ID"].Value;
            if (cellValue == null)
            {
                MessageBox.Show("Error al obtener el ID del boleto seleccionado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validaciones de campos obligatorios
            if (string.IsNullOrWhiteSpace(txtPrecio.Text))
            {
                MessageBox.Show("El precio es obligatorio", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrecio.Focus();
                return;
            }

            // Validar precio
            if (!decimal.TryParse(txtPrecio.Text, out decimal precio) || precio <= 0)
            {
                MessageBox.Show("El precio debe ser un número mayor a 0", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrecio.Focus();
                return;
            }

            if (precio > 1000)
            {
                MessageBox.Show("El precio no puede ser mayor a $1000", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrecio.Focus();
                return;
            }

            // Validar selecciones
            if (cmbBus.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar un bus", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbBus.Focus();
                return;
            }

            if (cmbRuta.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar una ruta", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbRuta.Focus();
                return;
            }

            // Validar fecha de venta
            if (dtpFechaVenta.Value > DateTime.Now)
            {
                MessageBox.Show("La fecha de venta no puede ser futura", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var db = new TransporteDbContext())
                {
                    int idBoleto = Convert.ToInt32(cellValue);
                    var boleto = db.Boletos.FirstOrDefault(b => b.IdBoleto == idBoleto);

                    if (boleto == null)
                    {
                        MessageBox.Show("No se encontró el boleto para modificar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Actualizar campos
                    boleto.IdBus = (int)cmbBus.SelectedValue;
                    boleto.IdRuta = (int)cmbRuta.SelectedValue;
                    boleto.FechaVenta = dtpFechaVenta.Value;
                    boleto.Precio = precio;

                    db.SaveChanges();
                }

                MessageBox.Show("Boleto modificado con éxito", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarBoletos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al modificar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
