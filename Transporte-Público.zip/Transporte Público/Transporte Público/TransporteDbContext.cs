﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using ComandosCreate.Model;

namespace Transporte_Público
{
    public class TransporteDbContext : DbContext
    {
        public TransporteDbContext() : base("name=TransporteDB") { }

        public DbSet<Chofer> Choferes { get; set; }
        public DbSet<Bus> Buses { get; set; }
        public DbSet<Ruta> Rutas { get; set; }
        public DbSet<Boleto> Boletos { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Chofer>().ToTable("Choferes").HasKey(c => c.IdChofer);
            modelBuilder.Entity<Bus>().ToTable("Buses").HasKey(b => b.IdBus);
            modelBuilder.Entity<Ruta>().ToTable("Rutas").HasKey(r => r.IdRuta);
            modelBuilder.Entity<Boleto>().ToTable("Boletos").HasKey(b => b.IdBoleto);


            modelBuilder.Entity<Bus>()
                .HasRequired(b => b.Chofer)
                .WithMany()
                .HasForeignKey(b => b.IdChofer);

            modelBuilder.Entity<Boleto>()
                .HasRequired(b => b.Bus)
                .WithMany()
                .HasForeignKey(b => b.IdBus);

            modelBuilder.Entity<Boleto>()
                .HasRequired(b => b.Ruta)
                .WithMany()
                .HasForeignKey(b => b.IdRuta);

            base.OnModelCreating(modelBuilder);
        }
    }
}
